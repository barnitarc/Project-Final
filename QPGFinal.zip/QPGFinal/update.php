<!DOCTYPE html>
<html style="font-size: 16px;">
  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta charset="utf-8">
    <meta name="keywords" content="">
    <meta name="description" content="">
    <meta name="page_type" content="np-template-header-footer-from-plugin">
    <title>modify user</title>
    <link rel="stylesheet" href="nicepage1.css" media="screen">
<link rel="stylesheet" href="update.css" media="screen">
    <script class="u-script" type="text/javascript" src="jquery.js" defer=""></script>
    <script class="u-script" type="text/javascript" src="nicepage.js" defer=""></script>
    <meta name="generator" content="Nicepage 4.6.5, nicepage.com">
    <link id="u-theme-google-font" rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i|Open+Sans:300,300i,400,400i,500,500i,600,600i,700,700i,800,800i">
    
    
    <script type="application/ld+json">{
		"@context": "http://schema.org",
		"@type": "Organization",
		"name": "",
		"logo": "images/logo.jpg"
}</script>
    <meta name="theme-color" content="#478ac9">
    <meta property="og:title" content="modify user">
    <meta property="og:type" content="website">
  </head>
  <body class="u-body u-xl-mode"><header class="u-clearfix u-header u-header" id="sec-167a"><div class="u-clearfix u-sheet u-sheet-1">
        <a href="dashboard.html" class="u-image u-logo u-image-1" data-image-width="612" data-image-height="612">
          <img src="images/logo.jpg" class="u-logo-image u-logo-image-1">
        </a>
        
        <h3 class="u-align-right u-headline u-text u-text-palette-5-dark-2 u-text-1">
          
          
            
          
          
            <a class="u-active-none u-border-none u-btn u-button-link u-button-style u-hover-none u-none u-text-palette-1-base u-btn-2" href="dashboard.html" data-page-id="66040615">Dashboard<span style="font-weight: 700;"></span>
            </a>
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a class="u-active-none u-border-none u-btn u-button-link u-button-style u-hover-none u-none u-text-palette-1-base u-btn-1" href="home.html">Log out<span style="font-weight: 700;"></span>
            </a>
          
        </h3>
        <h3 class="u-headline u-text u-text-grey-70 u-text-2">
          <a href="/">User-Administration
          </a>
        </h3><!--
        <p class="u-align-right u-text u-text-grey-75 u-text-3">
          <a class="u-active-none u-border-none u-btn u-button-link u-button-style u-hover-none u-none u-text-palette-1-base u-btn-1" href="home.html">Log out<span style="font-weight: 700;"></span>
          </a>
        </p>
        <p class="u-align-right u-text u-text-default u-text-4">
          <a class="u-active-none u-border-none u-btn u-button-link u-button-style u-hover-none u-none u-text-palette-1-base u-btn-2" href="dashboard.html" data-page-id="66040615">Dashboard<span style="font-weight: 700;"></span>
          </a>
        </p>-->
      </div></header>
<!--
    <section class="u-clearfix u-gradient u-section-1" id="sec-e4ec">
      <div class="u-clearfix u-sheet u-sheet-1">
        <p class="u-text u-text-default u-text-1">to delete select from userid. to modify fill all the deatils</p>
        <div class="u-form u-form-1">
          <form action="#" method="POST" class="u-clearfix u-form-custom-backend u-form-spacing-0 u-form-vertical u-inner-form" source="custom" name="form" style="padding: 30px;" redirect="true">
            <div class="u-form-group u-form-select u-form-group-1">
              <label for="select-4609" class="u-label">Select</label>
              <div class="u-form-select-wrapper">
                <select id="select-4609" name="select" class="u-border-2 u-border-grey-75 u-border-no-left u-border-no-right u-border-no-top u-input u-input-rectangle u-white">
                  <option value="Item 1">Item 1</option>
                  <option value="Item 2">Item 2</option>
                  <option value="Item 3">Item 3</option>
                </select>
                <svg xmlns="http://www.w3.org/2000/svg" width="14" height="12" version="1" class="u-caret"><path fill="currentColor" d="M4 8L0 4h8z"></path></svg>
              </div>
            </div>
            <div class="u-form-group u-form-name">
              <label for="name-6c03" class="u-label">Name</label>
              <input type="text" placeholder="Enter your Name" id="name-6c03" name="name" class="u-border-2 u-border-grey-75 u-border-no-left u-border-no-right u-border-no-top u-input u-input-rectangle u-white" required="">
            </div>
            <div class="u-form-email u-form-group">
              <label for="email-6c03" class="u-label">Email</label>
              <input type="email" placeholder="Enter a valid email address" id="email-6c03" name="email" class="u-border-2 u-border-grey-75 u-border-no-left u-border-no-right u-border-no-top u-input u-input-rectangle u-white" required="">
            </div>
            <div class="u-form-address u-form-group u-form-group-4">
              <label for="address-4cb0" class="u-label">Address</label>
              <input type="text" placeholder="Enter your address" id="address-4cb0" name="address" class="u-border-2 u-border-grey-75 u-border-no-left u-border-no-right u-border-no-top u-input u-input-rectangle u-white" required="">
            </div>
            <div class="u-form-group u-form-phone u-form-group-5">
              <label for="phone-7b7d" class="u-label">Phone</label>
              <input type="tel" pattern="\+?\d{0,3}[\s\(\-]?([0-9]{2,3})[\s\)\-]?([\s\-]?)([0-9]{3})[\s\-]?([0-9]{2})[\s\-]?([0-9]{2})" placeholder="Enter your phone (e.g. +14155552675)" id="phone-7b7d" name="phone" class="u-border-2 u-border-grey-75 u-border-no-left u-border-no-right u-border-no-top u-input u-input-rectangle u-white" required="">
              <br>
            </div>
          </div>
            

            <div style="align-items: center; display: flex;justify-content: center;">
                  
              <input type="submit" value="Update"  style="border-radius:15px; background-color:rgb(47, 112, 187); border-color:rgb(77, 141, 214) ;width: 200px; height: 42px;">
            </div>
          </form>
        
        
        
 <div class="u-form u-form-1">
          <form action="#" method="POST" class="u-clearfix u-form-custom-backend u-form-spacing-0 u-form-vertical u-inner-form" source="custom" name="form" style="padding: 30px;" redirect="true">
            <div class="u-form-group u-form-select u-form-group-1">
              <label for="select-4609" class="u-label">Select</label>
              <div class="u-form-select-wrapper">
                <select id="select-4609" name="select" class="u-border-2 u-border-grey-75 u-border-no-left u-border-no-right u-border-no-top u-input u-input-rectangle u-white">
                  <option value="Item 1">Item 1</option>
                  <option value="Item 2">Item 2</option>
                  <option value="Item 3">Item 3</option>
                </select>
                <br>
              </div>
                <div style="align-items: center; display: flex;justify-content: center;">
                  
                  <input type="submit" value="Delete"  style="border-radius:15px; background-color:rgb(47, 112, 187); border-color:rgb(77, 141, 214) ;width: 200px; height: 42px;">
                </div>
        <a href="user-administration.html" data-page-id="306820971" class="u-border-2 u-border-black u-btn u-button-style u-hover-black u-palette-1-light-2 u-text-black u-text-hover-white u-btn-4">back</a>
      </div>
    </section>-->
    
 <section class="u-clearfix u-gradient u-section-1" id="sec-778c">
      <div class="u-clearfix u-sheet u-sheet-1">
        <p class="u-text u-text-default u-text-palette-1-dark-1 u-text-1">Delete User<span style="font-weight: 700;"></span>
        </p>
        <p class="u-text u-text-default u-text-palette-1-dark-1 u-text-2">Modify User data</p>
        <div class="u-border-2 u-border-palette-1-dark-1 u-form u-form-1">
          <form action="modify.php" method="POST" class="u-clearfix u-form-custom-backend u-form-spacing-0 u-form-vertical u-inner-form" source="custom" name="form" style="padding: 44px;" redirect="true">
            
            
            <div class="u-form-group u-form-select u-form-group-1">
              <label for="select-3154" class="u-label">email</label>
              <div class="u-form-select-wrapper">
                  <?php
                  include ('connection.php');

                  $result=mysqli_query($conn,"Select uemail from tbuser");
                  $rows = mysqli_num_rows($result);
                echo '<select id="select-3154" name="uemail" class="u-border-1 u-border-grey-30 u-input u-input-rectangle u-radius-30 u-white">';?>
                 <?php
                 while($row=mysqli_fetch_assoc($result))
                {
                    ?>
                    <option value="<?php echo $row['uemail'];?>"><?php echo $row['uemail'];?></option>
                    <?php
                }
                ?>
                  
                </select>
                <svg xmlns="http://www.w3.org/2000/svg" width="14" height="12" version="1" class="u-caret"><path fill="currentColor" d="M4 8L0 4h8z"></path></svg>
              </div>
            </div>
            <div class="u-form-group u-form-group-2">
              <label for="text-934b" class="u-label">first name</label>
              <input type="text" placeholder="Enter first name" id="text-934b" name="fname" class="u-border-1 u-border-grey-30 u-input u-input-rectangle u-radius-30 u-white">
            </div>
            <div class="u-form-group u-form-name">
              <label for="name-d2af" class="u-label">Last name</label>
              <input type="text" placeholder="Enter last Name" id="name-d2af" name="lname" class="u-border-1 u-border-grey-30 u-input u-input-rectangle u-radius-30 u-white" required="">
            </div>
            <div class="u-form-group u-form-name">
              <label for="name-d2af" class="u-label">contact</label>
              <input type="text" placeholder="Enter contact" id="name-d2af" name="contact" class="u-border-1 u-border-grey-30 u-input u-input-rectangle u-radius-30 u-white" required="">
            </div>
            
            <div class="u-form-group u-form-group-5">
              <label for="text-5c06" class="u-label">Address</label>
              <input type="text" placeholder="address" id="text-5c06" name="address" class="u-border-1 u-border-grey-30 u-input u-input-rectangle u-radius-30 u-white">
            <br>
            </div>
            <!--
            <div class="u-align-left u-form-group u-form-submit">
              <a href="#" class="u-btn u-btn-submit u-button-style">Submit</a>
              <input type="submit" value="submit" class="u-form-control-hidden">
            </div>
            <div class="u-form-send-message u-form-send-success"> Thank you! Your message has been sent. </div>
            <div class="u-form-send-error u-form-send-message"> Unable to send your message. Please fix errors then try again. </div>
            <input type="hidden" value="" name="recaptchaResponse">-->
            <div style="align-items: center; display: flex;justify-content: center;">
                  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                  &nbsp;
                  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                  &nbsp;
                  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                  <div style="align-items: center">

                  <input type="submit" value="update"  style="border-radius:15px; background-color:rgb(47, 112, 187); border-color:rgb(77, 141, 214) ;width: 200px; height: 42px;">
                </div>
              </div>
              
          </form>
        </div>
        <div class="u-border-2 u-border-palette-1-dark-1 u-form u-form-2">
          <form action="del.php" method="POST" class="u-clearfix u-form-custom-backend u-form-spacing-10 u-form-vertical u-inner-form" source="custom" name="form-1" style="padding: 38px;" redirect="true">
            
            
            <div class="u-form-group u-form-select u-form-group-7">
              <label for="select-dbcc" class="u-label">email</label>
              <div class="u-form-select-wrapper">
              <?php
                  include ('connection.php');

                  $result=mysqli_query($conn,"Select uemail from tbuser");
                  $rows = mysqli_num_rows($result);
                echo '<select id="select-3154" name="email" class="u-border-1 u-border-grey-30 u-input u-input-rectangle u-radius-30 u-white">';?>
                 <?php
                 while($row=mysqli_fetch_assoc($result))
                {
                    ?>
                    <option value="<?php echo $row['uemail'];?>"><?php echo $row['uemail'];?></option>
                    <?php
                }
                ?>
                <br>
                <svg xmlns="http://www.w3.org/2000/svg" width="14" height="12" version="1" class="u-caret"><path fill="currentColor" d="M4 8L0 4h8z"></path></svg>
                <br>
              </div>
            </div>
            <br>
            <div style="align-items: center; display: flex;justify-content: center;">
                  
                  <div style="align-items: center">
                  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                  <input type="submit" value="delete" onclick="myFunction()" style="border-radius:15px; background-color:rgb(47, 112, 187); border-color:rgb(77, 141, 214) ;width: 200px; height: 42px;">
                </div>
              </div>
          </form>
        </div>
      </div>
    </section>
    <script>
function myFunction() {
  alert("I am an alert box!");
}
</script>
  
    
     <footer class="u-align-center u-clearfix u-footer u-grey-80 u-footer" id="sec-3c4b"><div class="u-clearfix u-sheet u-sheet-1">
        <p class="u-small-text u-text u-text-variant u-text-1">DESIGNED & DEVELOPED BY BASS</p>
      </div></footer>
    <section class="u-backlink u-clearfix u-grey-80">
      
      <p class="u-text">
        <span>COPYRIGHT 2022</span>
      </p>
      <a class="u-link" href="" target="_blank">
        <span>....</span>
      </a>. 
    </section>
  </body>
</html>