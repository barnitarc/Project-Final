<?php
ob_start();
echo "hello";
$out=ob_get_contents();
echo $out;
echo date("Y-m-d h:i:sa");
//file_put_contents('foo.html',$out);
?>