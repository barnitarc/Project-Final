<!DOCTYPE html>
<html style="font-size: 16px;">
  <head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta charset="utf-8">
    <meta name="keywords" content="">
    <meta name="description" content="">
    <meta name="page_type" content="np-template-header-footer-from-plugin">
    <title>finalpaper</title>
    <link rel="stylesheet" href="nicepage3.css" media="screen">
<link rel="stylesheet" href="finalpaper.css" media="screen">
    <script class="u-script" type="text/javascript" src="jquery.js" defer=""></script>
    <script class="u-script" type="text/javascript" src="nicepage.js" defer=""></script>
    <meta name="generator" content="Nicepage 4.6.5, nicepage.com">
    <link id="u-theme-google-font" rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i|Open+Sans:300,300i,400,400i,500,500i,600,600i,700,700i,800,800i">
    
    
    <script type="application/ld+json">{
		"@context": "http://schema.org",
		"@type": "Organization",
		"name": "",
		"logo": "images/logo.jpg"
}</script>
    <meta name="theme-color" content="#478ac9">
    <meta property="og:title" content="finalpaper">
    <meta property="og:type" content="website">
  </head>
  <body class="u-body u-xl-mode"><header class="u-clearfix u-header u-header" id="sec-41b0"><div class="u-clearfix u-sheet u-sheet-1">
        <!--<a href="https://nicepage.com" class="u-image u-logo u-image-1" data-image-width="612" data-image-height="612">
          <img src="images/logo.jpg" class="u-logo-image u-logo-image-1">
        </a>
        
      <header class="u-border-2 u-border-black u-border-no-left u-border-no-right u-border-no-top u-clearfix u-header u-header" id="sec-b8fc"><a href="https://nicepage.com" class="u-image u-logo u-image-1" data-image-width="612" data-image-height="612">
        <img src="images/logo.jpg" class="u-logo-image u-logo-image-1">
      </a><p class="u-text u-text-1">Add Questions</p><p class="u-align-right u-text u-text-2"><a href="home.html" class="u-border-1 u-border-active-palette-2-base u-border-hover-palette-1-base u-btn u-button-style u-none u-text-body-color u-btn-1">Log out</a><a href="dashboard.html" class="u-border-1 u-border-active-palette-2-base u-border-hover-palette-1-base u-btn u-button-style u-none u-text-body-color u-btn-2">Dashboard</a></p></header>
--><h3 class="u-headline u-text u-text-default u-text-1">
<a href="/">Question paper</a>
        </h3>
      </div></header>

<div id="bottom" style="height: 700px;">


<div id="content">
 <hr>
 
 <hr>
<!--<div id="menubar">
			<div id="menu1" class="menu_single_container"> <div class="padded_menu">Users</div> 
				<div id="drop1" class="drop">
					<ul>
						<li><a href ="#">Show Users</a></li>
						<li><a href ="delusers.php">Delete users</a></li>
					</ul>
				</div>
			</div>	
			<div id="menu2" class="menu_single_container"> <div class="padded_menu">Papers</div> 
				<div id="drop2" class="drop">
					<ul>
						<li><a href ="papers.php">Show papers</a></li>
						<li><a href ="addpaper.php">Add paper</a></li>
						<li>Delete paper</li>
						
					</ul>
				</div>	
			</div>
		
			</div>-->

<div id="papers_menu">


</div>
<hr>


</div>
<?php
include ('connection.php');
$server="localhost";
    $user="root";
    $password="";
    $conn=mysqli_connect($server,$user,$password);
    if($conn){
        //echo "<p> connected</p>";
    }
    else{
        echo "no";
    }
    mysqli_select_db($conn,"dbexam");
$subid=$_POST['subid'];
$sql="select subname from `tbsub` where subid='$subid'";
$res=mysqli_query($conn,$sql);
$row=mysqli_fetch_row($res);
$subject=$row[0];
//$qtype=$_POST["qtype"];
/*$noofquestions=$_POST["noofquestions"];
$totmarks=$_POST["totmarks"];*/

$mcq=$_POST["mcq"];
$mcqmarks=$_POST["mcqmarks"];
$unitmcq=$mcqmarks/$mcq;
$brief=$_POST["brief"];
$briefmarks=$_POST["briefmarks"];
$unitbrief=$briefmarks/$brief;
$long=$_POST["long"];
$longmarks=$_POST["longmarks"];
$unitlong=$longmarks/$long;

$date=$_POST["edate"];
$total=$mcqmarks+$briefmarks+$longmarks;

echo "<table  align='center' width='800'>";
echo"<tr>";
echo"<td><b>Subject :$subject</b></td>";

echo"<td colspan='2'></td>";

echo"<td align='right'><b>Marks : $total</b></td>";
 
echo"</tr>";

echo"<tr>";
echo"<td>&nbsp;</td>";

echo"<td colspan='2'></td>";
echo"<td align='right'><b>Date :$date</b></td>";

echo"</tr>";
echo"<tr>";
echo"<td>&nbsp;</td>";

echo"<td colspan='2'></td>";

 
echo"</tr>";

echo"<tr>";
echo"<td>&nbsp;</td>";
echo"<td colspan='2'>&nbsp;</td>"; 
echo"<td>&nbsp;</td>"; 

echo"</tr>";


//if ($qtype=="tbq1word")
{
	
$result=mysqli_query($conn,"Select * from tbqmcq where subid=$subid order by rand() limit $mcq");
echo "</table>";
echo"<table border='0' align='center' width='800'>";
$i=1;
echo "<tr>";
echo "<td>";
echo "<u><b>mcq questions</u></b>";
echo"<td colspan='2'>&nbsp;</td>";
echo"<td align='right'><b>$unitmcq X $mcq = $mcqmarks</b></td>";
echo "</tr>";
echo "</td>";
while($row = mysqli_fetch_assoc($result))
{
	
$num = $row['mcqid'];
//if(isset($_REQUEST[$num]))


echo"<tr>";
echo"<td>";
//$val = $row['mcqquestion']."  ".$row['a1'];
echo $i.".".$row['mcqquestion'];
//echo $row['a1']." ".$row['a2']."  ".$row['a3']."  ".$row['a4'];
echo"</td>";
echo"</tr>";
echo"<tr>";
echo"<td>";
$i=$i+1;
echo "&nbsp&nbsp&nbsp&nbspa)".$row['a1'];
echo"</td>";
echo"</tr>";
echo"<tr>";
echo"<td>";

echo "&nbsp&nbsp&nbsp&nbspb)".$row['a2'];
echo"</td>";
echo"</tr>";
echo"<tr>";
echo"<td>";

echo "&nbsp&nbsp&nbsp&nbspc)".$row['a3'];
echo"</td>";
echo"</tr>";
echo"<tr>";
echo"<td>";

echo "&nbsp&nbsp&nbsp&nbspd)".$row['a4'];
echo"</td>";
echo"</tr>";

}

echo "</table >";


$result=mysqli_query($conn,"Select * from tbqbrief where subid=$subid order by rand() limit $brief");
echo "</table>";
echo"<table border='0' align='center' width='800'>";
echo "<tr>";
echo "<td>";
echo "<u><b>brief questions</u></b>";
echo"<td colspan='2'>&nbsp;</td>";
echo"<td align='right'><b>$unitbrief X $brief = $briefmarks</b></td>";
echo "</tr>";
echo "</td>";
$i=0;
while($row = mysqli_fetch_assoc($result))
{
$num = $row['bid'];
//if(isset($_REQUEST[$num]))
{
$i=$i+1;
echo"<tr>";
echo"<td>";
//$val = $_REQUEST[$num];
echo $i.".".$row['bquestion'];
echo"</td>";
echo"</tr>";
}
}

echo "</table >";

$result=mysqli_query($conn,"Select * from tbq1word where subid=$subid order by rand() limit $long");
echo "</table>";
echo"<table border='0' align='center' width='800'>";
echo "<tr>";
echo "<td>";
echo "<u><b>long questions</u></b>";
echo"<td colspan='2'>&nbsp;</td>";
echo"<td align='right'><b>$unitlong X $long = $longmarks</b></td>";
echo "</tr>";
echo "</td>";
$i=0;
while($row = mysqli_fetch_assoc($result))
{
$num = $row['wordid'];
$i=$i+1;
echo"<tr>";
echo"<td>";
//$val = $_REQUEST[$num];
echo $i.".".$row['wquestion'];
echo"</td>";
echo"</tr>";
/*if(isset($_REQUEST[$num]))
{
echo"<tr>";
echo"<td>";
$val = $_REQUEST[$num];
echo $val;
echo"</td>";
echo"</tr>";
}*/
}
echo "</table >";
}
//else if ($qtype=="tbqbrief")


//else if($qtype=="tbqqmcq")





?>
<div style="text-align:center;">
<button  style="background-color:rgb(188, 176, 238)" onclick="myFunction()">Print this page</button>
<button  style="background-color:rgb(188, 176, 238)" onclick="location.href='generate-paper.php'">back</button>

<script>
function myFunction()
{
window.print();
}
</script>

    
    
    <!--<footer class="u-align-center u-clearfix u-footer u-grey-80 u-footer" id="sec-ea97"><div class="u-clearfix u-sheet u-sheet-1">
        <p class="u-small-text u-text u-text-variant u-text-1">Sample text. Click to select the text box. Click again or double click to start editing the text.</p>
      </div></footer>
    <section class="u-backlink u-clearfix u-grey-80">
      <a class="u-link" href="https://nicepage.com/templates" target="_blank">
        <span>Template</span>
      </a>
      <p class="u-text">
        <span>created with</span>
      </p>
      <a class="u-link" href="" target="_blank">
        <span>Website Builder Software</span>
      </a>. 
    </section>-->
  </body>
</html>